<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdmissionForm extends Model
{
    //
}
