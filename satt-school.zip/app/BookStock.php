<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookStock extends Model
{
    //
}
